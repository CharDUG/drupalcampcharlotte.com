Open Standard Media Player
=====================================

ABOUT:
   The open standard media player is an open source GPL - license free - full featured media player written in jQuery.
   It was designed to dynamically play any media thrown it's way, whether it be HTML5 video - Flash video - Audio, etc.

   Although this media player was designed to be used within a Content Management environment, such as Drupal, you can
   use this player for other applications outside of a CMS.

ENJOY!
